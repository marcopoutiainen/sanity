import {defineType, defineField} from 'sanity'

export const CardsSlider = defineType({
  name: 'cardsSlider',
  title: 'Cards Slider',
  type: 'document',
  fields: [
    defineField({
      name: 'slides',
      title: 'Slides',
      type: 'array',
      of: [
        defineField({
          name: 'slide',
          title: 'Slide',
          type: 'object',
          fields: [
            defineField({
              name: 'image',
              title: 'Image',
              type: 'image',
              options: {hotspot: true},
              description: 'Image for the slide.',
            }),
            defineField({
              name: 'title',
              title: 'Title',
              type: 'string',
              description: 'Optional title for the slide.',
            }),
            defineField({
              name: 'description',
              title: 'Description',
              type: 'text',
              description: 'Optional description for the slide.',
            }),
          ],
        }),
      ],
      description: 'Array of slides for the cards slider.',
    }),
  ],
})
