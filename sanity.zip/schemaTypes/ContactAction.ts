import {defineType, defineField} from 'sanity'

export const ContactAction = defineType({
  name: 'contactAction',
  title: 'Contact Action Section',
  type: 'document',
  fields: [
    defineField({
      name: 'title',
      title: 'Section Title',
      type: 'string',
      description: 'The title displayed at the top, e.g., "Kontakt".',
    }),
    defineField({
      name: 'headline',
      title: 'Headline',
      type: 'string',
      description: 'The main headline for this section, e.g., "Bereit für Neues?"',
    }),
    defineField({
      name: 'supportText',
      title: 'Support Text',
      type: 'text',
      description: 'Additional support text providing context, displayed in the support section.',
    }),
    defineField({
      name: 'image',
      title: 'Image',
      type: 'image',
      options: {hotspot: true},
      description: 'Image displayed on the left side of the component.',
    }),
    defineField({
      name: 'highlightText',
      title: 'Highlight Text',
      type: 'string',
      description: 'The text displayed in the highlight box, e.g., "Lerne uns kennen".',
    }),
    defineField({
      name: 'subtitle',
      title: 'Subtitle',
      type: 'string',
      description: 'The subtitle text displayed beneath the highlight text.',
    }),
    defineField({
      name: 'contactActions',
      title: 'Contact Actions',
      type: 'array',
      of: [
        defineField({
          name: 'action',
          title: 'Action',
          type: 'object',
          fields: [
            defineField({
              name: 'text',
              title: 'Action Text',
              type: 'string',
              description: 'The display text for the action, e.g., "Discovery Call buchen".',
            }),
            defineField({
              name: 'link',
              title: 'Action Link',
              type: 'url',
              description:
                'URL for the action link, e.g., "tel:+4733378901" or a link to the contact page.',
            }),
          ],
        }),
      ],
      description: 'Array of actions, each with a label and link.',
    }),
  ],
})
