// sanity/schemaTypes/testimonial.ts
import {defineType, defineField} from 'sanity'

export const Testimonial = defineType({
  name: 'testimonial',
  title: 'Testimonial',
  type: 'document',
  fields: [
    defineField({
      name: 'text',
      title: 'Testimonial Text',
      type: 'text',
      description: 'The main testimonial text.',
    }),
    defineField({
      name: 'author',
      title: 'Author or Source',
      type: 'string',
      description: 'The name of the author or source of the testimonial, e.g., "Google Review".',
    }),
    defineField({
      name: 'rating',
      title: 'Rating',
      type: 'number',
      description: 'The rating given, represented by the number of stars (1-5).',
      validation: (Rule) => Rule.required().min(1).max(5),
    }),
    defineField({
      name: 'color',
      title: 'Star Color',
      type: 'string',
      description:
        'Hex color code for the stars, e.g., #82E89D. Default colors will be used if empty.',
      initialValue: '#82E89D',
    }),
  ],
})
