// sanity/schemaTypes/index.ts
import {ClientsType} from './ClientsType'
import {HomePage} from './HomePage'
import {LogoType} from './Logo'
import {Footer} from './Footer'
import {Menu} from './Menu'
import {Slider} from './Slider'
import {Values} from './Values'
import {Missions} from './Missions'
import {Projects} from './Projects'
import {Testimonial} from './Testimonial'
import {ContactAction} from './ContactAction'
import {CardsSlider} from './CardsSlider'
import {Team} from './Team'
import {AboutUs} from './AboutUs'
import {CircularSlider} from './CircularSlider'
import {VerticalSlider} from './VerticalSlider'
import {Match} from './Match'
import {References} from './References'
import {WebDevelopment} from './WebDevelopment'
import {OnlineMarketing} from './OnlineMarketing'
import {Workshops} from './Workshops'

// Add Footer to the schemaTypes array
export const schemaTypes = [
  ClientsType,
  HomePage,
  LogoType,
  Footer,
  Menu,
  Slider,
  Values,
  Missions,
  Projects,
  Testimonial,
  ContactAction,
  CardsSlider,
  Team,
  AboutUs,
  CircularSlider,
  VerticalSlider,
  Match,
  References,
  WebDevelopment,
  OnlineMarketing,
  Workshops,
]
