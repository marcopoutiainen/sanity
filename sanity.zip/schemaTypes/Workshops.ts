import {defineType, defineField} from 'sanity'

export const Workshops = defineType({
  name: 'workshop',
  title: 'Workshop',
  type: 'document',
  fields: [
    defineField({
      name: 'title',
      title: 'Title',
      type: 'string',
    }),
    defineField({
      name: 'description',
      title: 'Description',
      type: 'text',
    }),
    defineField({
      name: 'image',
      title: 'Image',
      type: 'image',
      options: {hotspot: true},
    }),
    defineField({
      name: 'clients',
      title: 'Clients',
      type: 'array',
      of: [{type: 'string'}],
    }),
    defineField({
      name: 'values',
      title: 'Values',
      type: 'object',
      fields: [
        defineField({name: 'title', title: 'Title', type: 'string'}),
        defineField({name: 'headline', title: 'Headline', type: 'string'}),
        defineField({name: 'description', title: 'Description', type: 'text'}),
        defineField({
          name: 'items',
          title: 'Items',
          type: 'array',
          of: [
            defineField({
              name: 'item',
              title: 'Item',
              type: 'object',
              fields: [
                defineField({name: 'title', title: 'Item Title', type: 'string'}),
                defineField({name: 'description', title: 'Item Description', type: 'text'}),
              ],
            }),
          ],
        }),
      ],
    }),
    defineField({
      name: 'range',
      title: 'Range',
      type: 'object',
      fields: [
        defineField({name: 'title', title: 'Range Title', type: 'string'}),
        defineField({name: 'subtitle', title: 'Subtitle', type: 'string'}),
        defineField({
          name: 'description',
          title: 'Range Description',
          type: 'array',
          of: [{type: 'text'}],
        }),
        defineField({
          name: 'slides',
          title: 'Range Slides',
          type: 'array',
          of: [
            defineField({
              name: 'slide',
              title: 'Slide',
              type: 'object',
              fields: [
                defineField({name: 'title', title: 'Slide Title', type: 'string'}),
                defineField({name: 'content', title: 'Slide Content', type: 'text'}),
              ],
            }),
          ],
        }),
      ],
    }),
    defineField({
      name: 'workShopItem',
      title: 'Workshop Item',
      type: 'object',
      fields: [
        defineField({name: 'title', title: 'Title', type: 'string'}),
        defineField({name: 'subtitle', title: 'Subtitle', type: 'string'}),
        defineField({name: 'description', title: 'Description', type: 'text'}),
        defineField({name: 'link', title: 'Link', type: 'url'}),
        defineField({
          name: 'image',
          title: 'Image',
          type: 'image',
          options: {hotspot: true},
        }),
      ],
    }),
    defineField({
      name: 'event',
      title: 'Event',
      type: 'array',
      of: [
        defineField({
          name: 'eventItem',
          title: 'Event Item',
          type: 'object',
          fields: [
            defineField({name: 'title', title: 'Title', type: 'string'}),
            defineField({name: 'subtitle', title: 'Subtitle', type: 'string'}),
            defineField({name: 'location', title: 'Location', type: 'string'}),
            defineField({name: 'level', title: 'Level', type: 'string'}),
            defineField({name: 'duration', title: 'Duration', type: 'string'}),
          ],
        }),
      ],
      description: 'Event formats related to this workshop.',
    }),
  ],
})
