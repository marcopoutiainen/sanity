// sanity/schemaTypes/menu.ts
import {defineType, defineField} from 'sanity'

export const Menu = defineType({
  name: 'menu',
  title: 'Menu',
  type: 'document',
  fields: [
    defineField({
      name: 'parentUrl',
      title: 'Parent URL',
      type: 'string',
      description: 'Base URL for the menu links (e.g., "/recruiting" or "/solutions")',
    }),
    defineField({
      name: 'links',
      title: 'Menu Links',
      type: 'array',
      of: [
        defineField({
          name: 'menuItem',
          title: 'Menu Item',
          type: 'object',
          fields: [
            defineField({name: 'title', title: 'Title', type: 'string'}),
            defineField({name: 'path', title: 'Path', type: 'string'}), // Relative path (e.g., "/about-us")
          ],
        }),
      ],
    }),
    defineField({
      name: 'contact',
      title: 'Contact Information',
      type: 'object',
      fields: [
        defineField({name: 'email', title: 'Email', type: 'string'}),
        defineField({name: 'phone', title: 'Phone Number', type: 'string'}),
        defineField({name: 'addressLine1', title: 'Address Line 1', type: 'string'}),
        defineField({name: 'addressLine2', title: 'Address Line 2', type: 'string'}),
        defineField({name: 'city', title: 'City', type: 'string'}),
        defineField({name: 'state', title: 'State', type: 'string'}),
        defineField({name: 'zip', title: 'ZIP Code', type: 'string'}),
      ],
    }),
    defineField({
      name: 'socialLinks',
      title: 'Social Links',
      type: 'array',
      of: [
        defineField({
          name: 'socialLink',
          title: 'Social Link',
          type: 'object',
          fields: [
            defineField({name: 'platform', title: 'Platform', type: 'string'}),
            defineField({name: 'url', title: 'URL', type: 'url'}),
            defineField({name: 'icon', title: 'Icon', type: 'image'}),
          ],
        }),
      ],
    }),
  ],
})
