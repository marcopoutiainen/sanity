import {defineType, defineField} from 'sanity'

export const AboutUs = defineType({
  name: 'aboutUs',
  title: 'About Us Page',
  type: 'document',
  fields: [
    defineField({
      name: 'headline',
      title: 'Headline',
      type: 'string',
      description: 'Main headline text for the About Us page.',
    }),
    defineField({
      name: 'description',
      title: 'Description',
      type: 'text',
      description: 'A brief description or subtitle for the page.',
    }),
    defineField({
      name: 'text',
      title: 'Text Content',
      type: 'text',
      description: 'Additional text content with optional HTML styling.',
    }),
    defineField({
      name: 'cardsSlider',
      title: 'Cards Slider Section',
      type: 'reference',
      to: [{type: 'cardsSlider'}],
      description: 'Reference to the CardsSlider section.',
    }),
    defineField({
      name: 'values',
      title: 'Values Section',
      type: 'reference',
      to: [{type: 'values'}],
      description: 'Reference to the Values section.',
    }),
    defineField({
      name: 'team',
      title: 'Team Section',
      type: 'reference',
      to: [{type: 'team'}],
      description: 'Reference to the Team section.',
    }),
    defineField({
      name: 'testimonial',
      title: 'Testimonial Section',
      type: 'reference',
      to: [{type: 'testimonial'}],
      description: 'Reference to the Testimonial section.',
    }),
    defineField({
      name: 'contactAction',
      title: 'Contact Action Section',
      type: 'reference',
      to: [{type: 'contactAction'}],
      description: 'Reference to the ContactAction section.',
    }),
  ],
})
