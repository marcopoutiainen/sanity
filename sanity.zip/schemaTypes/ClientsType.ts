import {defineField, defineType} from 'sanity'

export const ClientsType = defineType({
  name: 'client',
  title: 'Client',
  type: 'document',
  fields: [
    defineField({
      name: 'name',
      title: 'Client Name',
      type: 'string',
      validation: (Rule) => Rule.required().min(1).max(100),
    }),
    defineField({
      name: 'description',
      title: 'Client Description',
      type: 'text',
      validation: (Rule) => Rule.max(200),
      description: 'A short description of the client or project.',
    }),
    defineField({
      name: 'image',
      title: 'Client Image',
      type: 'image',
      options: {
        hotspot: true, // Allows for image cropping and focusing in the Sanity Studio
      },
      validation: (Rule) => Rule.required(),
    }),
  ],
})
