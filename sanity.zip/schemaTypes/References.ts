import {defineType, defineField} from 'sanity'

export const References = defineType({
  name: 'references',
  title: 'References',
  type: 'document',
  fields: [
    defineField({name: 'title', title: 'Title', type: 'string'}),
    defineField({
      name: 'slug',
      title: 'Slug',
      type: 'slug',
      options: {source: 'title', maxLength: 200},
    }),
    defineField({name: 'description', title: 'Description', type: 'text'}),
    defineField({
      name: 'type',
      title: 'Reference Type',
      type: 'string',
      options: {
        list: [
          {title: 'Solution', value: 'solution'},
          {title: 'Recruiting', value: 'recruiting'},
        ],
        layout: 'radio',
      },
    }),
    defineField({
      name: 'clients',
      title: 'Clients',
      type: 'array',
      of: [{type: 'string'}],
    }),
    defineField({
      name: 'videos',
      title: 'Videos',
      type: 'array',
      of: [
        defineField({
          name: 'video',
          title: 'Video',
          type: 'object',
          fields: [
            defineField({name: 'title', title: 'Title', type: 'string'}),
            defineField({name: 'url', title: 'URL', type: 'url'}),
          ],
        }),
      ],
    }),
    defineField({
      name: 'factsData',
      title: 'Facts Data',
      type: 'array',
      of: [
        defineField({
          name: 'fact',
          title: 'Fact',
          type: 'object',
          fields: [{name: 'label', title: 'Label', type: 'string'}],
        }),
      ],
    }),
  ],
})
