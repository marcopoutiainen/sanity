// sanity/schemaTypes/values.ts
import {defineType, defineField} from 'sanity'

export const Values = defineType({
  name: 'values',
  title: 'Values Section',
  type: 'document',
  fields: [
    defineField({
      name: 'title',
      title: 'Title',
      type: 'string',
      description: 'The title displayed in the link button at the top.',
    }),
    defineField({
      name: 'headline',
      title: 'Headline',
      type: 'text',
      description: 'The main headline for this section, supports HTML for custom styling.',
    }),
    defineField({
      name: 'description',
      title: 'Description',
      type: 'text',
      description: 'A short description or subtitle for the values section.',
    }),
    defineField({
      name: 'items',
      title: 'Info Boxes',
      type: 'array',
      of: [
        defineField({
          name: 'item',
          title: 'Info Box Item',
          type: 'object',
          fields: [
            defineField({
              name: 'title',
              title: 'Item Title',
              type: 'string',
              description: 'Title of the info box item, displayed in a colored font.',
            }),
            defineField({
              name: 'description',
              title: 'Item Description',
              type: 'text',
              description: 'Description text for the info box item.',
            }),
          ],
        }),
      ],
      description: 'Array of info boxes to display in this section.',
    }),
  ],
})
