import {defineType, defineField} from 'sanity'

export const Projects = defineType({
  name: 'Projects',
  title: 'Projects Section',
  type: 'document',
  fields: [
    defineField({
      name: 'sectionTitle',
      title: 'Section Title',
      type: 'string',
      description: 'The title displayed at the top of the section (e.g., "Projekte").',
    }),
    defineField({
      name: 'header',
      title: 'Header',
      type: 'string',
      description: 'The main header text for the projects section.',
    }),
    defineField({
      name: 'projects',
      title: 'Projects',
      type: 'array',
      of: [
        defineField({
          name: 'project',
          title: 'Project',
          type: 'object',
          fields: [
            defineField({
              name: 'title',
              title: 'Project Title',
              type: 'string',
              description: 'Title of the project.',
            }),
            defineField({
              name: 'link',
              title: 'Project Link',
              type: 'url',
              description: 'Link to the project page or external URL.',
            }),
            defineField({
              name: 'description',
              title: 'Project Description',
              type: 'text',
              description: 'Short description of the project.',
            }),
            defineField({
              name: 'image',
              title: 'Project Image',
              type: 'image',
              options: {hotspot: true},
              description: 'Image displayed for the project.',
            }),
          ],
        }),
      ],
      description: 'Array of project items for the slider.',
    }),
  ],
})
