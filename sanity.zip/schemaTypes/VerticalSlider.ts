import {defineType, defineField} from 'sanity'

export const VerticalSlider = defineType({
  name: 'verticalSlider',
  title: 'Vertical Slider',
  type: 'document',
  fields: [
    defineField({
      name: 'title',
      title: 'Section Title',
      type: 'string',
      description: 'Title displayed at the top of the section, e.g., "Tools".',
    }),
    defineField({
      name: 'headline',
      title: 'Headline',
      type: 'string',
      description: 'Main headline text for the section, e.g., "Finden, statt suchen."',
    }),
    defineField({
      name: 'description',
      title: 'Description',
      type: 'text',
      description: 'Description for the section, e.g., about social media usage in the population.',
    }),
    defineField({
      name: 'slides',
      title: 'Slides',
      type: 'array',
      of: [
        defineField({
          name: 'slide',
          title: 'Slide',
          type: 'object',
          fields: [
            defineField({
              name: 'title',
              title: 'Slide Title',
              type: 'string',
              description: 'Title of the slide, e.g., "Direkte Ansprache".',
            }),
            defineField({
              name: 'content',
              title: 'Content',
              type: 'text',
              description: 'Content for the slide, describing details or benefits.',
            }),
          ],
        }),
      ],
      description: 'Array of slides to display in the vertical slider.',
    }),
  ],
})
