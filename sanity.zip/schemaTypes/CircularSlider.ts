import {defineType, defineField} from 'sanity'

export const CircularSlider = defineType({
  name: 'circularslider',
  title: 'Circular Slider',
  type: 'document',
  fields: [
    defineField({
      name: 'title',
      title: 'Section Title',
      type: 'string',
      description: 'The title displayed at the top of the section, e.g., "Referenzen".',
    }),
    defineField({
      name: 'headline',
      title: 'Headline',
      type: 'string',
      description:
        'Main headline text for the second section, e.g., "Ansprechend. Mit Reichweite."',
    }),
    defineField({
      name: 'description',
      title: 'Description',
      type: 'text',
      description: 'A short description for the second section.',
    }),
    defineField({
      name: 'circularCarouselItems',
      title: 'Carousel Items',
      type: 'array',
      of: [
        defineField({
          name: 'carouselItem',
          title: 'Carousel Item',
          type: 'object',
          fields: [
            defineField({
              name: 'title',
              title: 'Title',
              type: 'string',
              description: 'Title of the carousel item, e.g., "Slide 1".',
            }),
            defineField({
              name: 'image',
              title: 'Image',
              type: 'image',
              options: {hotspot: true},
              description: 'Image for the carousel item.',
            }),
          ],
        }),
      ],
      description: 'Array of items displayed in the circular carousel.',
    }),
    defineField({
      name: 'clients',
      title: 'Clients',
      type: 'array',
      of: [
        defineField({
          name: 'clientName',
          title: 'Client Name',
          type: 'string',
          description: 'Name of the client.',
        }),
      ],
      description: 'Array of client names for the Clients component.',
    }),
    defineField({
      name: 'supportText',
      title: 'Support Text',
      type: 'text',
      description: 'A short support message for the carousel section.',
    }),
  ],
})
