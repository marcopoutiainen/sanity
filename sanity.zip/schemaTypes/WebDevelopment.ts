import {defineType, defineField} from 'sanity'

export const WebDevelopment = defineType({
  name: 'webDevelopment',
  title: 'Web Development',
  type: 'document',
  fields: [
    defineField({
      name: 'title',
      title: 'Title',
      type: 'string',
    }),
    defineField({
      name: 'description',
      title: 'Description',
      type: 'text',
    }),
    defineField({
      name: 'image',
      title: 'Image',
      type: 'image',
      options: {hotspot: true},
    }),
    defineField({
      name: 'slogan',
      title: 'Slogan',
      type: 'object',
      fields: [
        defineField({
          name: 'subtitle',
          title: 'Subtitle',
          type: 'string',
        }),
        defineField({
          name: 'title',
          title: 'Slogan Title',
          type: 'string',
        }),
        defineField({
          name: 'description',
          title: 'Slogan Description',
          type: 'text',
        }),
        defineField({
          name: 'slides',
          title: 'Slides',
          type: 'array',
          of: [
            defineField({
              name: 'slide',
              title: 'Slide',
              type: 'object',
              fields: [
                defineField({name: 'title', title: 'Slide Title', type: 'string'}),
                defineField({name: 'content', title: 'Slide Content', type: 'text'}),
              ],
            }),
          ],
        }),
      ],
    }),
    defineField({
      name: 'range',
      title: 'Range',
      type: 'object',
      fields: [
        defineField({
          name: 'title',
          title: 'Range Title',
          type: 'string',
        }),
        defineField({
          name: 'description',
          title: 'Range Description',
          type: 'array',
          of: [{type: 'text'}],
        }),
        defineField({
          name: 'slides',
          title: 'Range Slides',
          type: 'array',
          of: [
            defineField({
              name: 'slide',
              title: 'Slide',
              type: 'object',
              fields: [
                defineField({name: 'title', title: 'Slide Title', type: 'string'}),
                defineField({name: 'content', title: 'Slide Content', type: 'text'}),
              ],
            }),
          ],
        }),
      ],
    }),
    defineField({
      name: 'serviceReferences',
      title: 'Service References',
      type: 'array',
      of: [
        defineField({
          name: 'referenceItem',
          title: 'Reference Item',
          type: 'object',
          fields: [
            defineField({name: 'title', title: 'Title', type: 'string'}),
            defineField({
              name: 'image',
              title: 'Image',
              type: 'image',
              options: {hotspot: true},
            }),
          ],
        }),
      ],
      description: 'List of service references specific to this web development entry.',
    }),
  ],
})
