// sanity/schemaTypes/Team.ts
import {defineType, defineField} from 'sanity'

export const Team = defineType({
  name: 'team',
  title: 'Team Section',
  type: 'document',
  fields: [
    defineField({
      name: 'sectionTitle',
      title: 'Section Title',
      type: 'string',
      description: 'Title displayed at the top of the team section, e.g., "Das Team".',
    }),
    defineField({
      name: 'headline',
      title: 'Headline',
      type: 'string',
      description: 'Main headline text for the team section, e.g., "Menschen dahinter."',
    }),
    defineField({
      name: 'description',
      title: 'Description',
      type: 'text',
      description: 'A short description for the team section.',
    }),
    defineField({
      name: 'members',
      title: 'Team Members',
      type: 'array',
      of: [
        defineField({
          name: 'member',
          title: 'Team Member',
          type: 'object',
          fields: [
            defineField({
              name: 'name',
              title: 'Name',
              type: 'string',
              description: 'Name of the team member.',
            }),
            defineField({
              name: 'title',
              title: 'Title',
              type: 'string',
              description: 'Position or title of the team member.',
            }),
            defineField({
              name: 'image',
              title: 'Image',
              type: 'image',
              options: {hotspot: true},
              description: 'Image of the team member.',
            }),
          ],
        }),
      ],
      description: 'Array of team members.',
    }),
  ],
})
