// sanity/schemaTypes/slider.ts
import {defineType, defineField} from 'sanity'

export const Slider = defineType({
  name: 'slider',
  title: 'Slider',
  type: 'document',
  fields: [
    defineField({
      name: 'sectionTitle',
      title: 'Section Title',
      type: 'string',
      description: 'The main title for this slider section',
    }),
    defineField({
      name: 'slides',
      title: 'Slides',
      type: 'array',
      of: [
        defineField({
          name: 'slide',
          title: 'Slide',
          type: 'object',
          fields: [
            defineField({
              name: 'title',
              title: 'Slide Title',
              type: 'string',
              description: 'Title of the individual slide',
            }),
            defineField({
              name: 'image',
              title: 'Image',
              type: 'image',
              options: {hotspot: true},
              description: 'Image for the slider',
            }),
            defineField({
              name: 'buttonTitle',
              title: 'Button Title',
              type: 'string',
              description: 'Title text for the button displayed on the slider',
            }),
          ],
        }),
      ],
      description: 'Array of slides within this section',
    }),
  ],
})
