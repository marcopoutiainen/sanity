import {defineType, defineField} from 'sanity'

export const Match = defineType({
  name: 'match',
  title: 'Match Section',
  type: 'document',
  fields: [
    defineField({
      name: 'title',
      title: 'Main Title',
      type: 'string',
      description: 'The main title of the section, e.g., "It’s a match!".',
    }),
    defineField({
      name: 'teamMembers',
      title: 'Team Members',
      type: 'array',
      of: [
        defineField({
          name: 'teamMember',
          title: 'Team Member',
          type: 'object',
          fields: [
            defineField({
              name: 'name',
              title: 'Name',
              type: 'string',
              description: 'The name of the team member, e.g., "Tobi".',
            }),
            defineField({
              name: 'role',
              title: 'Role',
              type: 'string',
              description: 'The role or title of the team member, e.g., "Recruitment Expert".',
            }),
          ],
        }),
      ],
      description: 'List of team members shown with animations.',
    }),
    defineField({
      name: 'mainImage',
      title: 'Main Image',
      type: 'image',
      options: {hotspot: true},
      description: 'Main image for the section background, e.g., team member or office photo.',
    }),
    defineField({
      name: 'subtitle',
      title: 'Subtitle',
      type: 'string',
      description:
        'Subtitle text for the section, e.g., "Gemeinsam in die Zukunft des Recruitment".',
    }),
    defineField({
      name: 'description',
      title: 'Description',
      type: 'text',
      description: 'Description about the team and section.',
    }),
    defineField({
      name: 'buttonText',
      title: 'Button Text',
      type: 'string',
      description: 'Text for the button at the end of the section.',
    }),
  ],
})
