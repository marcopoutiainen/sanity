import {defineType, defineField} from 'sanity'

export const LogoType = defineType({
  name: 'logo',
  title: 'Logo',
  type: 'document',
  fields: [
    defineField({
      name: 'name',
      title: 'Logo Name',
      type: 'string',
      description: 'A name to identify this logo (e.g., "Client Logo")',
    }),
    defineField({
      name: 'desktopLogo',
      title: 'Desktop Logo',
      type: 'image',
      options: {hotspot: true},
      description: 'Upload the desktop version of the logo',
    }),
    defineField({
      name: 'mobileLogo',
      title: 'Mobile Logo',
      type: 'image',
      options: {hotspot: true},
      description: 'Upload the mobile version of the logo',
    }),
  ],
})
