import {defineField, defineType} from 'sanity'

export const HomePage = defineType({
  name: 'homePage',
  title: 'Home Page',
  type: 'document',
  fields: [
    defineField({
      name: 'solutions_title',
      title: 'Solutions Title',
      type: 'string',
    }),
    defineField({
      name: 'solutions_subtitle',
      title: 'Solutions Subtitle',
      type: 'string',
    }),
    defineField({
      name: 'solutions_description',
      title: 'Solutions Description',
      type: 'text',
    }),
    defineField({
      name: 'recruiting_title',
      title: 'Recruiting Title',
      type: 'string',
    }),
    defineField({
      name: 'recruiting_subtitle',
      title: 'Recruiting Subtitle',
      type: 'string',
    }),
    defineField({
      name: 'recruiting_description',
      title: 'Recruiting Description',
      type: 'text',
    }),
  ],
})
