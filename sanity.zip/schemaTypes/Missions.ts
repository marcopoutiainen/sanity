// sanity/schemaTypes/missions.ts
import {defineType, defineField} from 'sanity'

export const Missions = defineType({
  name: 'missions',
  title: 'Missions Section',
  type: 'document',
  fields: [
    defineField({
      name: 'title',
      title: 'Section Title',
      type: 'string',
      description: 'The title displayed at the top of the missions section.',
    }),
    defineField({
      name: 'header',
      title: 'Header',
      type: 'string',
      description: 'The main header for the missions section.',
    }),
    defineField({
      name: 'description',
      title: 'Description',
      type: 'text',
      description: 'A short description for the missions section.',
    }),
    defineField({
      name: 'slides',
      title: 'Slides',
      type: 'array',
      of: [
        defineField({
          name: 'slide',
          title: 'Slide',
          type: 'object',
          fields: [
            defineField({
              name: 'backgroundColor',
              title: 'Background Color',
              type: 'string',
              description: 'Background color for the slide (e.g., #EDD5FF).',
            }),
            defineField({
              name: 'title',
              title: 'Slide Title',
              type: 'string',
              description: 'Title of the slide.',
            }),
            defineField({
              name: 'description',
              title: 'Description',
              type: 'text',
              description: 'Main description for the slide.',
            }),
            defineField({
              name: 'extraDescription',
              title: 'Extra Description',
              type: 'text',
              description: 'Additional description text for the slide.',
            }),
            defineField({
              name: 'image',
              title: 'Image',
              type: 'image',
              options: {hotspot: true},
              description: 'Image displayed on the slide.',
            }),
          ],
        }),
      ],
      description: 'Array of slides in the missions section.',
    }),
  ],
})
