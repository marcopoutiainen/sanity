import {defineType, defineField} from 'sanity'

export const OnlineMarketing = defineType({
  name: 'onlineMarketing',
  title: 'Online Marketing',
  type: 'document',
  fields: [
    defineField({
      name: 'title',
      title: 'Title',
      type: 'string',
      description: 'Title of the online marketing service.',
    }),
    defineField({
      name: 'image',
      title: 'Image',
      type: 'image',
      options: {hotspot: true},
      description: 'Main image for the service.',
    }),
    defineField({
      name: 'description',
      title: 'Description',
      type: 'text',
      description: 'Description for the online marketing service.',
    }),
    defineField({
      name: 'slogan',
      title: 'Slogan',
      type: 'object',
      fields: [
        defineField({name: 'subtitle', title: 'Subtitle', type: 'string'}),
        defineField({name: 'title', title: 'Slogan Title', type: 'string'}),
        defineField({name: 'description', title: 'Slogan Description', type: 'text'}),
        defineField({
          name: 'slides',
          title: 'Slides',
          type: 'array',
          of: [
            defineField({
              name: 'slide',
              title: 'Slide',
              type: 'object',
              fields: [
                defineField({name: 'title', title: 'Slide Title', type: 'string'}),
                defineField({name: 'content', title: 'Slide Content', type: 'text'}),
              ],
            }),
          ],
        }),
      ],
    }),
    defineField({
      name: 'fun',
      title: 'Fun Section',
      type: 'object',
      fields: [
        defineField({name: 'eyebrow', title: 'Eyebrow Text', type: 'string'}),
        defineField({name: 'title', title: 'Fun Title', type: 'string'}),
        defineField({name: 'content', title: 'Fun Content', type: 'text'}),
        defineField({name: 'linkText', title: 'Link Text', type: 'string'}),
        defineField({name: 'linkUrl', title: 'Link URL', type: 'url'}),
      ],
    }),
  ],
})
